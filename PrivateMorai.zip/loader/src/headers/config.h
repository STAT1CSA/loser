#pragma once

#define HTTP_SERVER "163.123.143.56"
#define HTTP_PORT 80

#define TFTP_SERVER "163.123.143.56"
